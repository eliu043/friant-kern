# The ground beneath the canal

Design Practices Assignment 04 • Astro–MapLibre spatial narrative • 13 November 2026

**Open the project folder in a terminal.** Requires npm 9+ and Node **22.23.4+** (Node 24 also works). An exact local Node development dependency is included for this machine; installing it does not replace your system Node.

```sh
npm ci
npm run dev
```

Open http://localhost:4321/. All five chapters and citations render as static HTML. Scroll to reveal the canal, regional displacement and sample points. Click **Explore map** to enable pan/pinch/keyboard zoom; wheel scrolling always advances the narrative. Use the five chapter buttons to jump, the opacity slider to compare, and **Reset view** to restore the current chapter. Click sample dots for their dated values. Context tiles can be switched off.

```sh
npm run build
npm run preview
```

Build runs Astro/TypeScript checks, validates the retained template YAML examples, and creates a static `dist/`. Preview at http://localhost:4321/. Serve `dist/` through any static HTTP server; do not open index.html through file://. No keys, login or database. Local core evidence assets are bundled; OSM orientation tiles require internet. Do not bulk-download OSM tiles. If Astro telemetry preferences are blocked on a restricted computer, run `ASTRO_TELEMETRY_DISABLED=1 npm run build` / `npm run dev` on macOS/Linux, or set that environment variable in your terminal on Windows.

## Deliverables

- `src/pages/index.astro`: narrative and source desk.
- `src/scripts/story.ts`: map, deterministic chapter states and controls.
- `src/styles/narrative.css`: desktop/mobile/reduced-motion layout.
- `public/data/`: local canal, georeferenced display raster and sampled observations.
- `research/FINDINGS.md`: concise decision, findings and limitations.
- `research/DATA_AUDIT.md`: provenance, resolution, dates, coverage, licensing and analytical gates.
- `research/CLAIM_EVIDENCE.csv`: accepted/rejected claims and permitted wording.
- `research/STORYBOARD.md`: five implemented chapters and conditional North Crimean sequence.
- `research/raw/`: original irrigation rasters, bounded DWR export and downloaded source metadata.
- `research/checksums.json`: raw-file SHA-256 inventory.
- `CODE_PROVENANCE.md`: template commit, AI assistance, adaptations and authorship disclosure required by the assignment.
- `VALIDATION.md`: checks completed and verification limits.

## Regenerate research assets (optional)

The web app does not need Python. To reproduce local processing, use Python 3.9+:

```sh
python3 -m venv .venv
.venv/bin/pip install rasterio==1.4.3 numpy==2.0.2 pillow==11.3.0 pyproj==3.6.1
.venv/bin/python scripts/audit_irrigation.py
.venv/bin/python scripts/prepare_data.py
```

On Windows use `.venv\Scripts\python` / `pip`. Processing is deterministic and uses the retained original files, without a live API. `prepare_data.py` preserves the DWR export’s actual spatial extent and uses nearest-neighbor reprojection. No satellite classification is retrained and no hydraulic simulation is run. For original retrieval URLs/parameters see the audit.

## Publication

This is a local prototype, as allowed by the assignment. For root-path hosting upload `dist/`. For GitHub Pages under a repository subpath, set Astro `base` and update absolute font URLs in `narrative.css`; then rebuild. Confirm the mirrored centerline distribution terms before wider public release. Source dataset terms are not a license for the application code.
