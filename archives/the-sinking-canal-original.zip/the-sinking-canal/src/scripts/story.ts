import * as maplibregl from 'maplibre-gl';
import workerUrl from 'maplibre-gl/dist/maplibre-gl-worker.mjs?worker&url';
maplibregl.setWorkerUrl(workerUrl);
import 'maplibre-gl/dist/maplibre-gl.css';
import meta from '../../public/data/raster-meta.json';
import samples from '../../public/data/samples.geojson?raw';
import canal from '../../public/data/canal.geojson?raw';
const $ = (id:string) => document.getElementById(id)!;
const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const views = [
 {center:[-119.38,36.22],zoom:7.7}, {center:[-119.22,36.08],zoom:8.7},
 {center:[-119.13,36.00],zoom:9.3}, {center:[-119.10,35.95],zoom:9.5},
 {center:[-119.22,36.05],zoom:8.7}
];
const stages=['01 / Reference alignment','02 / Regional ground movement','03 / Three sampled cells','04 / The engineering record','05 / Evidence & its limits'];
const notes=['Reference centerline · no service territory implied','DWR / TRE ALTAMIRA · cumulative displacement · feet','Select a dot to read the regional raster sample','Reference alignment · project boundaries not mapped','Regional evidence · no well-level attribution'];
let active=0,loaded=false,exploring=false,opacity=.85;
try {
 const map = new maplibregl.Map({container:'map',center:views[0].center as [number,number],zoom:views[0].zoom,attributionControl:{compact:true},pitch:0,bearing:0,style:{version:8,sources:{context:{type:'raster',tiles:['https://tile.openstreetmap.org/{z}/{x}/{y}.png'],tileSize:256,attribution:'© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'}},layers:[{id:'paper',type:'background',paint:{'background-color':'#e2e8da'}},{id:'context',type:'raster',source:'context',paint:{'raster-opacity':.26,'raster-saturation':-.9}}]}});
 map.addControl(new maplibregl.NavigationControl({showCompass:false}),'top-right');
 map.addControl(new maplibregl.ScaleControl({unit:'metric'}),'bottom-left');
 map.scrollZoom.disable();map.dragPan.disable();map.dragRotate.disable();map.doubleClickZoom.disable();map.touchZoomRotate.disable();map.keyboard.disable();
 function update(){
  document.querySelectorAll('.chapter-nav a').forEach((a,i)=>a.setAttribute('aria-current',String(i===active)));
  $('map-stage').textContent=stages[active];$('map-note').textContent=notes[active];$('legend').hidden=active===0;
  if(!loaded)return;
  map.setPaintProperty('displacement','raster-opacity',active===0?0:opacity);
  map.setLayoutProperty('samples','visibility',active>=2?'visible':'none');
  map.easeTo({...views[active],center:views[active].center as [number,number],duration:reduced?0:650});
 }
 map.on('load',()=>{
  map.addSource('displacement',{type:'image',url:`${import.meta.env.BASE_URL}data/displacement.png`,coordinates:meta.coordinates as [[number,number],[number,number],[number,number],[number,number]]});
  map.addLayer({id:'displacement',type:'raster',source:'displacement',paint:{'raster-opacity':0,'raster-fade-duration':0,'raster-resampling':'nearest'}});
  map.addSource('canal',{type:'geojson',data:JSON.parse(canal),attribution:'Canal: federal compilation via public ArcGIS mirror · DWR / TRE ALTAMIRA displacement'});
  map.addLayer({id:'canal-halo',type:'line',source:'canal',paint:{'line-color':'#f6f4e9','line-width':5}});
  map.addLayer({id:'canal',type:'line',source:'canal',paint:{'line-color':'#244d43','line-width':2.2}});
  map.addSource('samples',{type:'geojson',data:JSON.parse(samples)});
  map.addLayer({id:'samples',type:'circle',source:'samples',layout:{visibility:'none'},paint:{'circle-radius':7,'circle-color':'#f8f4e8','circle-stroke-color':'#243d33','circle-stroke-width':2}});
  // Local DOM locators remain legible even if external map tiles are unavailable.
  for(const [name,lng,lat] of [['Friant Dam',-119.705,36.999],['Lindsay',-119.088,36.203],['Terra Bella',-119.045,35.962],['Delano',-119.248,35.768],['Bakersfield',-119.019,35.374]] as [string,number,number][]){
   const el=document.createElement('span');el.textContent=name;el.style.cssText='font:10px Mona,Arial;color:#203e32;background:#f4f1e9c9;padding:2px 4px;pointer-events:none';
   new maplibregl.Marker({element:el,anchor:'left',offset:[8,0]}).setLngLat([lng,lat]).addTo(map);
  }
  map.on('click','samples',e=>{const f=e.features?.[0];if(!f)return;const p=f.properties!;const content=document.createElement('div');const strong=document.createElement('strong');strong.textContent=p.name;const text=document.createElement('p');text.textContent=`${p.feet??'No data'} ft · 13 Jun 2015–1 Jan 2024. ${p.note}`;content.append(strong,text);new maplibregl.Popup().setLngLat(e.lngLat).setDOMContent(content).addTo(map);});
  map.on('mouseenter','samples',()=>{map.getCanvas().style.cursor='pointer'});map.on('mouseleave','samples',()=>{map.getCanvas().style.cursor=exploring?'grab':''});
  loaded=true;update();
 });
 let tileErrors=0;
 map.on('error',()=>{tileErrors++;if(tileErrors>2)$('map-note').textContent='Some map resources failed. Local evidence layers remain available when loaded.';});
 $('explore').addEventListener('click',()=>{exploring=!exploring;$('explore').setAttribute('aria-pressed',String(exploring));$('explore').textContent=exploring?'Exit exploration':'Explore map';if(exploring){map.dragPan.enable();map.doubleClickZoom.enable();map.touchZoomRotate.enable();map.touchZoomRotate.disableRotation();map.keyboard.enable();}else{map.dragPan.disable();map.doubleClickZoom.disable();map.touchZoomRotate.disable();map.keyboard.disable();} });
 $('reset').addEventListener('click',update);
 $('context').addEventListener('change',e=>map.setLayoutProperty('context','visibility',(e.target as HTMLInputElement).checked?'visible':'none'));
 $('opacity').addEventListener('input',e=>{opacity=Number((e.target as HTMLInputElement).value)/100;if(loaded&&active>0)map.setPaintProperty('displacement','raster-opacity',opacity);});
 const sections=Array.from(document.querySelectorAll<HTMLElement>('.chapter'));
 let scheduled=false;
 function selectChapter(){scheduled=false;const mobile=window.innerWidth<=760;const target=window.innerHeight*(mobile?.72:.5);let best=0,dist=Infinity;sections.forEach((el,i)=>{const r=el.getBoundingClientRect();const d=Math.abs(r.top+r.height/2-target);if(d<dist){best=i;dist=d;}});if(best!==active){active=best;update();}}
 window.addEventListener('scroll',()=>{if(!scheduled){scheduled=true;requestAnimationFrame(selectChapter)}},{passive:true});
 window.addEventListener('resize',()=>{map.resize();selectChapter()});
 update();selectChapter();
} catch(error){$('map-failure').hidden=false;console.error('Map initialization failed',error);}
